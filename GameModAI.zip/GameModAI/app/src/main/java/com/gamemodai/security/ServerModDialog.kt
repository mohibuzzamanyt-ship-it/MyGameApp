package com.gamemodai.security

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.gamemodai.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Dialog for configuring server-side value modification
 */
class ServerModDialog : DialogFragment() {

    private lateinit var serverValueModifier: ServerValueModifier
    private var selectedPackageName: String = ""

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = MaterialAlertDialogBuilder(requireContext())
        val inflater = requireActivity().layoutInflater
        val view = inflater.inflate(R.layout.dialog_server_mod, null)

        // Initialize the server value modifier
        serverValueModifier = ServerValueModifier(requireContext())

        // Set up the package name spinner
        setupPackageSpinner(view)

        // Set up the start button
        val startButton = view.findViewById<Button>(R.id.btnStartProxy)
        startButton.setOnClickListener {
            startServerMod()
        }

        // Set up the add value button
        val addValueButton = view.findViewById<Button>(R.id.btnAddValue)
        addValueButton.setOnClickListener {
            addValueModification(view)
        }

        return builder
            .setView(view)
            .setTitle("Server-Side Value Modification")
            .setNegativeButton("Close") { _, _ -> dismiss() }
            .create()
    }

    /**
     * Set up the package name spinner
     */
    private fun setupPackageSpinner(view: View) {
        val spinner = view.findViewById<Spinner>(R.id.spinnerPackage)
        val packageManager = requireContext().packageManager
        val installedApps = packageManager.getInstalledApplications(0)
            .filter { it.packageName != requireContext().packageName }
            .sortedBy { packageManager.getApplicationLabel(it).toString() }

        val packageNames = installedApps.map { 
            "${packageManager.getApplicationLabel(it)} (${it.packageName})" 
        }

        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            packageNames
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedPackageName = installedApps[position].packageName
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedPackageName = ""
            }
        }
    }

    /**
     * Start the server-side value modification
     */
    private fun startServerMod() {
        if (selectedPackageName.isEmpty()) {
            Toast.makeText(requireContext(), "Please select a package", Toast.LENGTH_SHORT).show()
            return
        }

        // Start the VPN service
        val result = serverValueModifier.startVpnService(selectedPackageName)
        if (result) {
            Toast.makeText(requireContext(), "Server modification started", Toast.LENGTH_SHORT).show()
        } else {
            // Show VPN permission dialog
            Toast.makeText(requireContext(), "VPN permission required", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Add a value modification
     */
    private fun addValueModification(view: View) {
        val keyEditText = view.findViewById<EditText>(R.id.etKey)
        val valueEditText = view.findViewById<EditText>(R.id.etValue)
        
        val key = keyEditText.text.toString()
        val valueStr = valueEditText.text.toString()
        
        if (key.isEmpty() || valueStr.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter key and value", Toast.LENGTH_SHORT).show()
            return
        }
        
        // Try to parse the value as different types
        try {
            // Try as integer
            val intValue = valueStr.toInt()
            serverValueModifier.addValueModification(key, intValue)
            Toast.makeText(requireContext(), "Added integer value modification", Toast.LENGTH_SHORT).show()
            return
        } catch (e: NumberFormatException) {
            // Not an integer
        }
        
        try {
            // Try as float
            val floatValue = valueStr.toFloat()
            serverValueModifier.addValueModification(key, floatValue)
            Toast.makeText(requireContext(), "Added float value modification", Toast.LENGTH_SHORT).show()
            return
        } catch (e: NumberFormatException) {
            // Not a float
        }
        
        try {
            // Try as boolean
            if (valueStr.equals("true", ignoreCase = true) || valueStr.equals("false", ignoreCase = true)) {
                val boolValue = valueStr.equals("true", ignoreCase = true)
                serverValueModifier.addValueModification(key, boolValue)
                Toast.makeText(requireContext(), "Added boolean value modification", Toast.LENGTH_SHORT).show()
                return
            }
        } catch (e: Exception) {
            // Not a boolean
        }
        
        // Default to string
        serverValueModifier.addValueModification(key, valueStr)
        Toast.makeText(requireContext(), "Added string value modification", Toast.LENGTH_SHORT).show()
        
        // Clear the input fields
        keyEditText.text.clear()
        valueEditText.text.clear()
    }
}