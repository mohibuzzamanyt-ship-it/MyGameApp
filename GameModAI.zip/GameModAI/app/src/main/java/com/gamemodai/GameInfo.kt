package com.gamemodai

import android.graphics.drawable.Drawable

/**
 * Data class to hold information about a running game
 */
data class GameInfo(
    val name: String,
    val packageName: String,
    val processId: Int,
    val icon: Drawable
)