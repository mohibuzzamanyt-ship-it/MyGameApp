package com.gamemodai.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gamemodai.R
import com.google.android.material.textfield.TextInputEditText

/**
 * Activity for app review and download
 */
class AppReviewActivity : AppCompatActivity() {

    private lateinit var ratingBar: RatingBar
    private lateinit var feedbackEditText: TextInputEditText
    private lateinit var submitButton: Button
    private lateinit var downloadButton: Button
    private lateinit var ratingFeedbackText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_review)

        // Initialize views
        ratingBar = findViewById(R.id.ratingBar)
        feedbackEditText = findViewById(R.id.feedbackEditText)
        submitButton = findViewById(R.id.submitButton)
        downloadButton = findViewById(R.id.downloadButton)
        ratingFeedbackText = findViewById(R.id.ratingFeedbackText)

        // Set up rating bar listener
        ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            updateRatingFeedback(rating)
        }

        // Set up submit button
        submitButton.setOnClickListener {
            submitReview()
        }

        // Set up download button
        downloadButton.setOnClickListener {
            downloadApp()
        }
    }

    /**
     * Update the rating feedback text based on the rating
     */
    private fun updateRatingFeedback(rating: Float) {
        val feedback = when {
            rating <= 1 -> "We're sorry to hear that! Please let us know how we can improve."
            rating <= 2 -> "Thanks for your feedback. How can we make it better?"
            rating <= 3 -> "Thanks for your rating. We're working to improve!"
            rating <= 4 -> "Great! Thanks for your positive feedback!"
            else -> "Excellent! We're glad you're enjoying the app!"
        }
        ratingFeedbackText.text = feedback
        ratingFeedbackText.visibility = View.VISIBLE
    }

    /**
     * Submit the review
     */
    private fun submitReview() {
        val rating = ratingBar.rating
        val feedback = feedbackEditText.text.toString()

        // Validate input
        if (rating == 0f) {
            Toast.makeText(this, "Please provide a rating", Toast.LENGTH_SHORT).show()
            return
        }

        // In a real app, we would send this data to a server
        // For now, just show a toast
        Toast.makeText(this, "Thank you for your feedback!", Toast.LENGTH_SHORT).show()

        // Clear the form
        ratingBar.rating = 0f
        feedbackEditText.setText("")
        ratingFeedbackText.visibility = View.GONE
    }

    /**
     * Download the app
     */
    private fun downloadApp() {
        // In a real app, this would link to the Play Store or a download page
        // For now, just open a dummy URL
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.gamemodai"))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open download link", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Share the app with friends
     */
    fun shareApp(view: View) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Check out this amazing game modding app: https://play.google.com/store/apps/details?id=com.gamemodai")
            type = "text/plain"
        }
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }
}