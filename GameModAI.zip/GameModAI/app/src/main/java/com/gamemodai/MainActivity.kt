package com.gamemodai

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.gamemodai.databinding.ActivityMainBinding
import com.gamemodai.hacks.EasyModeActivity
import com.gamemodai.security.ServerModDialog
import com.gamemodai.ui.AppReviewActivity
import com.github.jaredrummler.android.processes.AndroidProcesses
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var gameAdapter: GameAdapter
    private val gameList = mutableListOf<GameInfo>()
    
    companion object {
        private const val MENU_REVIEW = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setSupportActionBar(binding.toolbar)
        
        setupRecyclerView()
        
        binding.btnScanGames.setOnClickListener {
            scanForRunningGames()
        }
        
        // Set up Easy Mode button
        binding.btnEasyMode.setOnClickListener {
            if (gameList.isNotEmpty()) {
                val selectedGame = gameList.first()
                val intent = Intent(this, EasyModeActivity::class.java).apply {
                    putExtra("PACKAGE_NAME", selectedGame.packageName)
                    putExtra("PROCESS_ID", selectedGame.processId)
                    putExtra("GAME_NAME", selectedGame.name)
                }
                startActivity(intent)
            } else {
                scanForRunningGames()
            }
        }
        
        // Set up Server Mod button
        binding.btnServerMod.setOnClickListener {
            ServerModDialog().show(supportFragmentManager, "ServerModDialog")
        }
        
        // Check for root access
        checkRootAccess()
    }
    
    private fun setupRecyclerView() {
        gameAdapter = GameAdapter(gameList) { gameInfo ->
            // Handle game selection - open scanning activity
            val intent = Intent(this, GameScanActivity::class.java).apply {
                putExtra("PACKAGE_NAME", gameInfo.packageName)
                putExtra("PROCESS_ID", gameInfo.processId)
                putExtra("GAME_NAME", gameInfo.name)
            }
            startActivity(intent)
        }
        
        binding.rvRunningGames.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = gameAdapter
        }
    }
    
    private fun checkRootAccess() {
        if (!GameModApplication.isRooted) {
            // Show root access required dialog
            RootAccessDialog().show(supportFragmentManager, "RootAccessDialog")
        }
    }
    
    private fun scanForRunningGames() {
        CoroutineScope(Dispatchers.Main).launch {
            binding.btnScanGames.isEnabled = false
            
            val runningGames = withContext(Dispatchers.IO) {
                val games = mutableListOf<GameInfo>()
                val packageManager = packageManager
                
                // Get all running processes
                val runningProcesses = AndroidProcesses.getRunningProcesses()
                
                // Filter for installed apps that might be games
                val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                    .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 } // Non-system apps
                
                for (process in runningProcesses) {
                    val packageName = process.packageName ?: continue
                    
                    // Find the app info for this process
                    val appInfo = installedApps.find { it.packageName == packageName } ?: continue
                    
                    // Check if it's likely a game (this is a simple heuristic)
                    val isGame = packageName.contains("game", ignoreCase = true) || 
                                 isGameByCategory(packageName, packageManager)
                    
                    if (isGame) {
                        val name = packageManager.getApplicationLabel(appInfo).toString()
                        val icon = packageManager.getApplicationIcon(appInfo)
                        games.add(GameInfo(name, packageName, process.pid, icon))
                    }
                }
                
                games
            }
            
            // Update UI with found games
            gameList.clear()
            gameList.addAll(runningGames)
            gameAdapter.notifyDataSetChanged()
            
            // Show empty state if no games found
            if (runningGames.isEmpty()) {
                binding.tvNoGames.visibility = View.VISIBLE
                binding.rvRunningGames.visibility = View.GONE
            } else {
                binding.tvNoGames.visibility = View.GONE
                binding.rvRunningGames.visibility = View.VISIBLE
            }
            
            binding.btnScanGames.isEnabled = true
        }
    }
    
    private fun isGameByCategory(packageName: String, packageManager: PackageManager): Boolean {
        try {
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_META_DATA)
            val category = packageInfo.applicationInfo.category
            
            // Check if it's in the GAME category
            return category == ApplicationInfo.CATEGORY_GAME
        } catch (e: Exception) {
            return false
        }
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(Menu.NONE, MENU_REVIEW, Menu.NONE, "Rate & Download")
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            MENU_REVIEW -> {
                startActivity(Intent(this, AppReviewActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}