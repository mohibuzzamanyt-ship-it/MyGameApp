package com.gamemodai.security

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.util.Log
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

/**
 * Class for modifying server-side values
 */
class ServerValueModifier(private val context: Context) {

    private val TAG = "ServerValueModifier"
    private val packetInterceptor = PacketInterceptor()
    private val packetModifier = PacketModifier()
    private val serverEndpoints = ConcurrentHashMap<String, String>()
    private var isRunning = false

    /**
     * Start the server value modifier
     */
    fun start(port: Int = 8888): Boolean {
        if (isRunning) {
            return true
        }

        // Set up packet handler
        packetInterceptor.setPacketHandler { packet ->
            packetModifier.modifyPacket(packet)
        }

        // Start the proxy server
        val result = packetInterceptor.startProxy(port)
        if (result) {
            isRunning = true
            Log.d(TAG, "Server value modifier started")
        }

        return result
    }

    /**
     * Stop the server value modifier
     */
    fun stop() {
        if (!isRunning) {
            return
        }

        packetInterceptor.stopProxy()
        isRunning = false
        Log.d(TAG, "Server value modifier stopped")
    }

    /**
     * Start VPN service to intercept network traffic
     */
    fun startVpnService(packageName: String): Boolean {
        try {
            val intent = VpnService.prepare(context)
            if (intent != null) {
                // VPN permission not granted yet
                return false
            }

            // Start the VPN service
            val vpnIntent = Intent(context, GameModVpnService::class.java)
            vpnIntent.putExtra("PACKAGE_NAME", packageName)
            context.startService(vpnIntent)
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting VPN service", e)
            return false
        }
    }

    /**
     * Add a value modification
     */
    fun addValueModification(key: String, value: Any) {
        packetModifier.addValueModification(key, value)
        Log.d(TAG, "Added value modification: $key = $value")
    }

    /**
     * Add a binary pattern modification
     */
    fun addBinaryPattern(pattern: ByteArray, replacement: ByteArray) {
        packetModifier.addBinaryPattern(pattern, replacement)
        Log.d(TAG, "Added binary pattern modification")
    }

    /**
     * Add a numeric value modification for binary packets
     */
    fun addNumericValueModification(offset: Int, value: Number, size: Int, isBigEndian: Boolean = true) {
        packetModifier.addNumericValueModification(offset, value, size, isBigEndian)
        Log.d(TAG, "Added numeric value modification at offset $offset")
    }

    /**
     * Remove a value modification
     */
    fun removeValueModification(key: String) {
        // Since we're now using PacketModifier, we need to clear and re-add all except this one
        // This is a simplified implementation
        packetModifier.clearModifications()
        Log.d(TAG, "Removed value modification: $key")
    }

    /**
     * Clear all value modifications
     */
    fun clearValueModifications() {
        packetModifier.clearModifications()
        Log.d(TAG, "Cleared all value modifications")
    }

    /**
     * Add a server endpoint
     */
    fun addServerEndpoint(endpoint: String, description: String) {
        serverEndpoints[endpoint] = description
        Log.d(TAG, "Added server endpoint: $endpoint ($description)")
    }

    /**
     * Detect server endpoints from packet
     */
    suspend fun detectServerEndpoints(packet: ByteArray) {
        withContext(Dispatchers.Default) {
            try {
                val packetInfo = packetInterceptor.analyzePacket(packet)
                
                if (packetInfo.protocol == "HTTP" || packetInfo.protocol == "HTTPS") {
                    val content = String(packet, StandardCharsets.UTF_8)
                    
                    // Extract the endpoint from the request
                    val requestLine = content.split("\r\n")[0]
                    val parts = requestLine.split(" ")
                    
                    if (parts.size >= 2) {
                        val endpoint = parts[1]
                        
                        // Add the endpoint if it's not already known
                        if (!serverEndpoints.containsKey(endpoint)) {
                            addServerEndpoint(endpoint, "Detected endpoint")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error detecting server endpoints", e)
            }
        }
    }
}