package com.gamemodai

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

/**
 * Dialog that informs the user about root access requirements
 */
class RootAccessDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            .setTitle("Root Access Required")
            .setMessage(getString(R.string.root_required))
            .setPositiveButton("OK") { _, _ ->
                // User acknowledged the requirement
                dismiss()
            }
            .setNegativeButton("Exit") { _, _ ->
                // User wants to exit the app
                requireActivity().finish()
            }
            .setCancelable(false)
            .create()
    }
}