package com.gamemodai.security

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

/**
 * Class for modifying network packets in various formats
 */
class PacketModifier {
    private val TAG = "PacketModifier"
    private val gson = Gson()
    private val valueModifications = ConcurrentHashMap<String, Any>()
    private val binaryPatterns = ConcurrentHashMap<ByteArray, ByteArray>()

    /**
     * Add a value modification for JSON packets
     */
    fun addValueModification(key: String, value: Any) {
        valueModifications[key] = value
        Log.d(TAG, "Added value modification: $key = $value")
    }

    /**
     * Add a binary pattern replacement
     */
    fun addBinaryPattern(pattern: ByteArray, replacement: ByteArray) {
        binaryPatterns[pattern] = replacement
        Log.d(TAG, "Added binary pattern replacement")
    }

    /**
     * Clear all modifications
     */
    fun clearModifications() {
        valueModifications.clear()
        binaryPatterns.clear()
        Log.d(TAG, "Cleared all modifications")
    }

    /**
     * Modify a packet
     */
    fun modifyPacket(packet: ByteArray): ByteArray {
        // Skip if no modifications
        if (valueModifications.isEmpty() && binaryPatterns.isEmpty()) {
            return packet
        }

        try {
            // Try to parse as JSON
            val jsonModified = modifyJsonPacket(packet)
            if (jsonModified != null) {
                return jsonModified
            }

            // Try to modify as binary packet
            return modifyBinaryPacket(packet)
        } catch (e: Exception) {
            Log.e(TAG, "Error modifying packet", e)
            return packet
        }
    }

    /**
     * Modify a JSON packet
     */
    private fun modifyJsonPacket(packet: ByteArray): ByteArray? {
        try {
            val content = String(packet, StandardCharsets.UTF_8)
            
            // Check if it looks like JSON
            if (!content.trim().startsWith("{") && !content.trim().startsWith("[")) {
                return null
            }

            // For HTTP packets, separate headers and body
            var headers = ""
            var jsonContent = content
            
            if (content.contains("\r\n\r\n")) {
                val parts = content.split("\r\n\r\n", limit = 2)
                headers = parts[0] + "\r\n\r\n"
                jsonContent = parts[1]
            }

            // Try to parse JSON
            try {
                val jsonElement = JsonParser.parseString(jsonContent)
                
                // Modify JSON
                val modified = modifyJsonElement(jsonElement)
                
                // If nothing was modified, return null
                if (!modified) {
                    return null
                }
                
                // Convert back to string
                val modifiedContent = gson.toJson(jsonElement)
                
                // Combine headers and modified content
                val finalContent = headers + modifiedContent
                
                // Convert to bytes
                return finalContent.toByteArray(StandardCharsets.UTF_8)
            } catch (e: Exception) {
                // Not valid JSON
                return null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error modifying JSON packet", e)
            return null
        }
    }

    /**
     * Modify a JSON element
     */
    private fun modifyJsonElement(element: JsonElement): Boolean {
        var modified = false
        
        if (element.isJsonObject) {
            val jsonObject = element.asJsonObject
            
            // Check each property
            for ((key, value) in jsonObject.entrySet()) {
                // Check if this key should be modified
                if (valueModifications.containsKey(key)) {
                    val newValue = valueModifications[key]
                    when (newValue) {
                        is Int -> jsonObject.addProperty(key, newValue)
                        is Long -> jsonObject.addProperty(key, newValue)
                        is Float -> jsonObject.addProperty(key, newValue)
                        is Double -> jsonObject.addProperty(key, newValue)
                        is Boolean -> jsonObject.addProperty(key, newValue)
                        is String -> jsonObject.addProperty(key, newValue)
                        else -> continue
                    }
                    modified = true
                }
                
                // Recursively check nested objects
                if (value.isJsonObject || value.isJsonArray) {
                    val nestedModified = modifyJsonElement(value)
                    modified = modified || nestedModified
                }
            }
        } else if (element.isJsonArray) {
            val jsonArray = element.asJsonArray
            
            // Check each element in the array
            for (i in 0 until jsonArray.size()) {
                val item = jsonArray.get(i)
                if (item.isJsonObject || item.isJsonArray) {
                    val nestedModified = modifyJsonElement(item)
                    modified = modified || nestedModified
                }
            }
        }
        
        return modified
    }

    /**
     * Modify a binary packet
     */
    private fun modifyBinaryPacket(packet: ByteArray): ByteArray {
        // If no binary patterns, return original
        if (binaryPatterns.isEmpty()) {
            return packet
        }

        var modifiedPacket = packet

        // Apply each binary pattern replacement
        for ((pattern, replacement) in binaryPatterns) {
            modifiedPacket = replaceBinaryPattern(modifiedPacket, pattern, replacement)
        }

        return modifiedPacket
    }

    /**
     * Replace a binary pattern in a packet
     */
    private fun replaceBinaryPattern(data: ByteArray, pattern: ByteArray, replacement: ByteArray): ByteArray {
        // Simple pattern matching and replacement
        if (pattern.size > data.size || pattern.isEmpty()) {
            return data
        }

        val result = ByteArray(data.size)
        System.arraycopy(data, 0, result, 0, data.size)

        var i = 0
        while (i <= data.size - pattern.size) {
            var matches = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) {
                    matches = false
                    break
                }
            }

            if (matches) {
                // Replace the pattern
                for (j in replacement.indices) {
                    if (i + j < result.size) {
                        result[i + j] = replacement[j]
                    }
                }
                i += pattern.size
            } else {
                i++
            }
        }

        return result
    }

    /**
     * Add a numeric value modification for binary packets
     */
    fun addNumericValueModification(offset: Int, value: Number, size: Int, isBigEndian: Boolean = true) {
        try {
            // Create pattern and replacement
            val pattern = ByteArray(size)
            val replacement = ByteArray(size)
            
            // Create buffer for replacement
            val buffer = ByteBuffer.wrap(replacement)
            if (!isBigEndian) {
                buffer.order(ByteOrder.LITTLE_ENDIAN)
            }
            
            // Write the value
            when (size) {
                1 -> replacement[0] = value.toByte()
                2 -> buffer.putShort(value.toShort())
                4 -> buffer.putInt(value.toInt())
                8 -> buffer.putLong(value.toLong())
                else -> throw IllegalArgumentException("Unsupported size: $size")
            }
            
            // Add the pattern with offset
            val offsetPattern = ByteArray(offset + pattern.size)
            val offsetReplacement = ByteArray(offset + replacement.size)
            System.arraycopy(pattern, 0, offsetPattern, offset, pattern.size)
            System.arraycopy(replacement, 0, offsetReplacement, offset, replacement.size)
            
            addBinaryPattern(offsetPattern, offsetReplacement)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding numeric value modification", e)
        }
    }
}