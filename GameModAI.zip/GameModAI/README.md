# GameModAI

GameModAI is an advanced Android application for game modification, similar to Game Guardian. It allows users to select other applications, decrypt their files if necessary, and extract/modify values.

## Features

- **Game Selection**: Browse and select installed games on your device
- **Memory Scanning**: Scan game memory for specific values (integers, floats, strings)
- **AI-Powered Detection**: Automatically detect important game values using AI
- **Value Modification**: Modify memory values in real-time
- **Value Freezing**: Freeze values to prevent them from changing
- **File Decryption**: Automatically detect and decrypt encrypted game files
- **Root Access**: Utilizes root permissions for advanced functionality

## Requirements

- Android 8.0 (API level 26) or higher
- Rooted device
- Storage permissions

## Installation

1. Download the APK from the releases section
2. Enable "Install from Unknown Sources" in your device settings
3. Install the APK
4. Grant root permissions when prompted

## Usage Guide

### Selecting a Game

1. Launch GameModAI
2. Browse the list of installed games
3. Tap on a game to select it
4. Tap "Scan Memory" to begin analyzing the game

### Scanning for Values

1. Enter a value to search for (e.g., current health, coins, etc.)
2. Select the value type (Integer, Float, String, etc.)
3. Tap "Search" to find all occurrences of that value
4. Alternatively, use "AI Scan" to automatically detect important game values

### Modifying Values

1. From the scan results, tap on a value to open the Value Editor
2. View the current value and memory address
3. Enter a new value in the input field
4. Tap "Apply Changes" to modify the value in the game

### Freezing Values

1. In the Value Editor, tap "Freeze Value" to lock a value
2. The value will remain constant even if the game tries to change it
3. Tap "Unfreeze Value" to allow the game to modify the value again

### Handling Encrypted Files

1. GameModAI automatically detects encrypted game files
2. Various decryption methods are attempted automatically
3. Decrypted files are saved for faster access in future sessions

## Troubleshooting

### Root Access Issues

- Ensure your device is properly rooted
- Grant root permissions when prompted
- If root access is denied, try using a different root management app

### Game Compatibility

- Not all games can be modified due to anti-cheat protections
- Some games may crash when values are modified
- Online games may detect modifications and ban your account

### Performance Issues

- Close other memory-intensive apps before using GameModAI
- Limit the number of frozen values to improve performance
- Use more specific search criteria to reduce the number of results

## Security Notice

This application is for educational purposes only. Modifying games may violate terms of service and could result in account bans. Use at your own risk.

## Privacy

GameModAI does not collect or transmit any personal data. All operations are performed locally on your device.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- libsu for root access functionality
- TensorFlow Lite for AI-powered value detection