package com.gamemodai

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gamemodai.databinding.ItemGameBinding

class GameAdapter(
    private val games: List<GameInfo>,
    private val onGameSelected: (GameInfo) -> Unit
) : RecyclerView.Adapter<GameAdapter.GameViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameViewHolder {
        val binding = ItemGameBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return GameViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GameViewHolder, position: Int) {
        holder.bind(games[position])
    }

    override fun getItemCount(): Int = games.size

    inner class GameViewHolder(private val binding: ItemGameBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(gameInfo: GameInfo) {
            binding.apply {
                ivGameIcon.setImageDrawable(gameInfo.icon)
                tvGameName.text = gameInfo.name
                tvPackageName.text = gameInfo.packageName
                tvProcessId.text = "PID: ${gameInfo.processId}"
                
                btnScan.setOnClickListener {
                    onGameSelected(gameInfo)
                }
            }
        }
    }
}