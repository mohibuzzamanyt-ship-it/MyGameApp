package com.gamemodai.testing

import android.content.Context
import android.util.Log
import com.gamemodai.GameValue
import com.gamemodai.memory.MemoryScanner
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Utility class for testing the app with various games
 */
class GameTestUtil(private val context: Context) {
    
    private val TAG = "GameTestUtil"
    private val memoryScanner = MemoryScanner()
    
    /**
     * Tests memory scanning functionality with a specific game
     * @param packageName The package name of the game to test
     * @return List of found game values or null if test failed
     */
    suspend fun testMemoryScanning(packageName: String): List<GameValue>? {
        return withContext(Dispatchers.IO) {
            try {
                // Get process ID
                val pidCommand = "pidof $packageName"
                val result = Shell.cmd(pidCommand).exec()
                
                if (!result.isSuccess) {
                    Log.e(TAG, "Failed to get PID for $packageName")
                    return@withContext null
                }
                
                val pid = result.out.firstOrNull()?.trim()?.toIntOrNull()
                if (pid == null) {
                    Log.e(TAG, "Invalid PID for $packageName")
                    return@withContext null
                }
                
                // Initialize memory scanner
                memoryScanner.initialize(pid)
                
                // Test scanning for integer values
                val intValues = memoryScanner.scanForValue(100, MemoryScanner.ValueType.INT)
                
                // Test scanning for float values
                val floatValues = memoryScanner.scanForValue(100.0f, MemoryScanner.ValueType.FLOAT)
                
                // Combine results
                val gameValues = mutableListOf<GameValue>()
                
                intValues.take(5).forEach { address ->
                    gameValues.add(GameValue(
                        address = address,
                        valueType = "Integer",
                        currentValue = "100",
                        description = "Test integer value"
                    ))
                }
                
                floatValues.take(5).forEach { address ->
                    gameValues.add(GameValue(
                        address = address,
                        valueType = "Float",
                        currentValue = "100.0",
                        description = "Test float value"
                    ))
                }
                
                return@withContext gameValues
                
            } catch (e: Exception) {
                Log.e(TAG, "Error testing memory scanning", e)
                return@withContext null
            }
        }
    }
    
    /**
     * Tests file decryption functionality
     * @param packageName The package name of the game to test
     * @return True if decryption test passed, false otherwise
     */
    suspend fun testFileDecryption(packageName: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                // Get app data directory
                val dataDir = "/data/data/$packageName"
                
                // Check if we can access the directory
                val result = Shell.cmd("ls -la $dataDir").exec()
                if (!result.isSuccess) {
                    Log.e(TAG, "Failed to access data directory for $packageName")
                    return@withContext false
                }
                
                // Look for potential encrypted files
                val filesResult = Shell.cmd("find $dataDir -name \"*.dat\" -o -name \"*.bin\" -o -name \"*.sav\"").exec()
                if (!filesResult.isSuccess || filesResult.out.isEmpty()) {
                    Log.e(TAG, "No potential encrypted files found for $packageName")
                    return@withContext false
                }
                
                // Try to analyze the first file
                val targetFile = filesResult.out.first()
                val tempFile = File(context.cacheDir, "test_decryption.bin")
                
                // Copy file to temp location
                val copyResult = Shell.cmd("cat $targetFile > ${tempFile.absolutePath}").exec()
                if (!copyResult.isSuccess) {
                    Log.e(TAG, "Failed to copy file for analysis")
                    return@withContext false
                }
                
                // Test basic XOR decryption
                val fileBytes = tempFile.readBytes()
                val entropy = calculateEntropy(fileBytes)
                
                Log.d(TAG, "File entropy: $entropy")
                
                // Clean up
                tempFile.delete()
                
                return@withContext true
                
            } catch (e: Exception) {
                Log.e(TAG, "Error testing file decryption", e)
                return@withContext false
            }
        }
    }
    
    /**
     * Calculate Shannon entropy of byte array
     * Higher values indicate more randomness (possibly encrypted)
     */
    private fun calculateEntropy(bytes: ByteArray): Double {
        val frequencies = IntArray(256)
        bytes.forEach { byte ->
            frequencies[byte.toInt() and 0xFF]++
        }
        
        var entropy = 0.0
        val size = bytes.size.toDouble()
        
        for (frequency in frequencies) {
            if (frequency > 0) {
                val probability = frequency / size
                entropy -= probability * (Math.log(probability) / Math.log(2.0))
            }
        }
        
        return entropy
    }
}