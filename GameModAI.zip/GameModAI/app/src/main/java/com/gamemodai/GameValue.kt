package com.gamemodai

import com.gamemodai.memory.ValueType

/**
 * Represents a value found in memory that can be modified
 */
data class GameValue(
    val address: Long,
    val valueType: ValueType,
    val value: String,
    val description: String = ""
)