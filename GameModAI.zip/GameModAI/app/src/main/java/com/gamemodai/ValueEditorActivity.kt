package com.gamemodai

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gamemodai.databinding.ActivityValueEditorBinding
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Timer
import java.util.TimerTask

class ValueEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityValueEditorBinding
    private var memoryAddress: String = ""
    private var valueType: String = ""
    private var currentValue: String = ""
    private var processId: Int = -1
    private var isFrozen: Boolean = false
    private var freezeTimer: Timer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityValueEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Get data from intent
        memoryAddress = intent.getStringExtra("address") ?: ""
        valueType = intent.getStringExtra("valueType") ?: ""
        currentValue = intent.getStringExtra("currentValue") ?: ""
        processId = intent.getIntExtra("processId", -1)

        // Display data
        binding.tvAddress.text = memoryAddress
        binding.tvValueType.text = valueType
        binding.tvCurrentValue.text = currentValue
        binding.etNewValue.setText(currentValue)

        // Set up button click listeners
        binding.btnApply.setOnClickListener {
            val newValue = binding.etNewValue.text.toString()
            if (newValue.isNotEmpty()) {
                applyValueChange(newValue)
            } else {
                Toast.makeText(this, "Please enter a value", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnFreeze.setOnClickListener {
            toggleFreezeValue()
        }
        
        // Check for root access
        if (!Shell.rootAccess()) {
            Toast.makeText(this, R.string.root_required, Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun applyValueChange(newValue: String) {
        if (processId <= 0) {
            Toast.makeText(this, "Invalid process ID", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val result = writeMemoryValue(processId, memoryAddress, newValue, valueType)
                
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    if (result) {
                        binding.tvCurrentValue.text = newValue
                        Toast.makeText(this@ValueEditorActivity, 
                            "Value successfully modified", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@ValueEditorActivity, 
                            "Failed to modify value", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this@ValueEditorActivity, 
                        "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun toggleFreezeValue() {
        if (isFrozen) {
            // Stop freezing
            freezeTimer?.cancel()
            freezeTimer = null
            isFrozen = false
            binding.btnFreeze.text = getString(R.string.freeze_value)
            binding.btnFreeze.backgroundTintList = resources.getColorStateList(R.color.accent, theme)
            Toast.makeText(this, "Value unfrozen", Toast.LENGTH_SHORT).show()
        } else {
            // Start freezing
            val valueToFreeze = binding.etNewValue.text.toString()
            if (valueToFreeze.isEmpty()) {
                Toast.makeText(this, "Please enter a value to freeze", Toast.LENGTH_SHORT).show()
                return
            }

            // First apply the value
            applyValueChange(valueToFreeze)
            
            // Then start the freeze timer
            freezeTimer = Timer()
            freezeTimer?.scheduleAtFixedRate(object : TimerTask() {
                override fun run() {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            writeMemoryValue(processId, memoryAddress, valueToFreeze, valueType)
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@ValueEditorActivity, 
                                    "Freeze error: ${e.message}", Toast.LENGTH_SHORT).show()
                                toggleFreezeValue() // Stop freezing on error
                            }
                        }
                    }
                }
            }, 0, 1000) // Apply every second
            
            isFrozen = true
            binding.btnFreeze.text = getString(R.string.unfreeze_value)
            binding.btnFreeze.backgroundTintList = resources.getColorStateList(R.color.red, theme)
            Toast.makeText(this, "Value frozen - will be maintained automatically", Toast.LENGTH_SHORT).show()
        }
    }

    private suspend fun writeMemoryValue(pid: Int, address: String, value: String, type: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                // Format depends on value type
                val formattedValue = when (type.uppercase()) {
                    "INT" -> value.toIntOrNull()?.toString() ?: value
                    "FLOAT" -> value.toFloatOrNull()?.toString() ?: value
                    "DOUBLE" -> value.toDoubleOrNull()?.toString() ?: value
                    "LONG" -> value.toLongOrNull()?.toString() ?: value
                    "BYTE" -> value.toByteOrNull()?.toString() ?: value
                    "SHORT" -> value.toShortOrNull()?.toString() ?: value
                    "STRING" -> "\"$value\""
                    else -> value
                }

                // Use root shell to write to memory
                val command = "su -c 'echo $formattedValue > /proc/$pid/mem' 2>&1"
                val result = Shell.cmd(command).exec()
                
                // Check if command was successful
                result.isSuccess
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        freezeTimer?.cancel()
        freezeTimer = null
    }
}