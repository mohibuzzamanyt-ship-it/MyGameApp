package com.gamemodai.security

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import kotlin.concurrent.thread

/**
 * VPN service for intercepting network traffic
 */
class GameModVpnService : VpnService() {

    private val TAG = "GameModVpnService"
    private var vpnInterface: ParcelFileDescriptor? = null
    private var isRunning = false
    private var targetPackageName: String? = null
    private val serverValueModifier = ServerValueModifier(this)

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "VPN service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            return START_NOT_STICKY
        }

        targetPackageName = intent.getStringExtra("PACKAGE_NAME")
        if (targetPackageName == null) {
            Log.e(TAG, "No package name provided")
            return START_NOT_STICKY
        }

        // Start the VPN
        startVpn()

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVpn()
        Log.d(TAG, "VPN service destroyed")
    }

    /**
     * Start the VPN
     */
    private fun startVpn() {
        if (isRunning) {
            return
        }

        try {
            // Configure the VPN
            val builder = Builder()
                .setSession("GameModAI VPN")
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")

            // Add the target package to the VPN
            if (targetPackageName != null) {
                builder.addAllowedApplication(targetPackageName!!)
            }

            // Establish the VPN interface
            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                Log.e(TAG, "Failed to establish VPN interface")
                return
            }

            isRunning = true
            Log.d(TAG, "VPN started for package: $targetPackageName")

            // Start processing packets
            CoroutineScope(Dispatchers.IO).launch {
                processPackets()
            }

            // Start the server value modifier
            serverValueModifier.start()

        } catch (e: Exception) {
            Log.e(TAG, "Error starting VPN", e)
            stopVpn()
        }
    }

    /**
     * Stop the VPN
     */
    private fun stopVpn() {
        if (!isRunning) {
            return
        }

        try {
            isRunning = false
            vpnInterface?.close()
            vpnInterface = null
            serverValueModifier.stop()
            Log.d(TAG, "VPN stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping VPN", e)
        }
    }

    /**
     * Process packets
     */
    private fun processPackets() {
        val vpnInput = FileInputStream(vpnInterface?.fileDescriptor)
        val vpnOutput = FileOutputStream(vpnInterface?.fileDescriptor)
        val buffer = ByteBuffer.allocate(32767)

        try {
            val datagramChannel = DatagramChannel.open()
            datagramChannel.configureBlocking(false)
            protect(datagramChannel.socket())

            while (isRunning) {
                // Read from VPN interface
                buffer.clear()
                val length = vpnInput.read(buffer.array())
                if (length <= 0) {
                    Thread.sleep(100)
                    continue
                }

                buffer.limit(length)

                // Process the packet
                val packet = ByteArray(length)
                System.arraycopy(buffer.array(), 0, packet, 0, length)

                // Modify the packet
                val modifiedPacket = serverValueModifier.modifyPacket(packet)

                // Write the modified packet back to the VPN interface
                vpnOutput.write(modifiedPacket)
                vpnOutput.flush()

                // Detect server endpoints
                CoroutineScope(Dispatchers.IO).launch {
                    serverValueModifier.detectServerEndpoints(packet)
                }
            }

            datagramChannel.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error processing packets", e)
        }
    }
}