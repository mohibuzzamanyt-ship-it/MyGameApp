package com.gamemodai

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class GameValueAdapter(
    private val gameValues: List<GameValue>,
    private val onItemClick: (GameValue) -> Unit
) : RecyclerView.Adapter<GameValueAdapter.GameValueViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameValueViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_game_value, parent, false)
        return GameValueViewHolder(view)
    }

    override fun onBindViewHolder(holder: GameValueViewHolder, position: Int) {
        val gameValue = gameValues[position]
        holder.bind(gameValue)
    }

    override fun getItemCount(): Int = gameValues.size

    inner class GameValueViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvAddress: TextView = itemView.findViewById(R.id.tvAddress)
        private val tvValueType: TextView = itemView.findViewById(R.id.tvValueType)
        private val tvValue: TextView = itemView.findViewById(R.id.tvValue)
        private val tvDescription: TextView = itemView.findViewById(R.id.tvDescription)
        private val cardView: MaterialCardView = itemView.findViewById(R.id.cardView)

        fun bind(gameValue: GameValue) {
            tvAddress.text = "0x${gameValue.address.toString(16)}"
            tvValueType.text = gameValue.valueType.name
            tvValue.text = gameValue.value
            
            if (gameValue.description.isNotEmpty()) {
                tvDescription.visibility = View.VISIBLE
                tvDescription.text = gameValue.description
            } else {
                tvDescription.visibility = View.GONE
            }

            cardView.setOnClickListener {
                onItemClick(gameValue)
            }
        }
    }
}