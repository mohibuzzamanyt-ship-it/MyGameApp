package com.gamemodai

import android.app.Application
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class GameModApplication : Application() {

    companion object {
        var isRooted = false
        private var tflite: Interpreter? = null
    }

    override fun onCreate() {
        super.onCreate()
        
        // Initialize root shell
        Shell.enableVerboseLogging = BuildConfig.DEBUG
        Shell.setDefaultBuilder(Shell.Builder.create()
            .setFlags(Shell.FLAG_REDIRECT_STDERR)
            .setTimeout(10)
        )
        
        // Check for root access
        CoroutineScope(Dispatchers.IO).launch {
            isRooted = Shell.rootAccess()
        }
        
        // Initialize AI model
        initializeAIModel()
    }
    
    private fun initializeAIModel() {
        try {
            val assetManager = assets
            val modelFile = "game_value_detector.tflite"
            
            // Check if model exists
            val modelExists = assetManager.list("")?.contains(modelFile) ?: false
            
            if (modelExists) {
                assetManager.open(modelFile).use { fileInputStream ->
                    val fileChannel = fileInputStream.channel
                    val startOffset = 0L
                    val declaredLength = fileInputStream.available().toLong()
                    val modelBuffer = fileChannel.map(
                        FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
                    
                    // Initialize TFLite interpreter
                    tflite = Interpreter(modelBuffer)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    fun getInterpreter(): Interpreter? {
        return tflite
    }
}