package com.gamemodai.hacks

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gamemodai.R
import com.gamemodai.databinding.ActivityEasyModeBinding
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.launch

class EasyModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEasyModeBinding
    private var processId: Int = -1
    private var packageName: String = ""
    private var gameName: String = ""
    private lateinit var easyModeManager: EasyModeManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEasyModeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Set up toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        // Get intent extras
        processId = intent.getIntExtra("PROCESS_ID", -1)
        packageName = intent.getStringExtra("PACKAGE_NAME") ?: ""
        gameName = intent.getStringExtra("GAME_NAME") ?: "Unknown Game"
        
        // Set game name
        binding.tvGameName.text = "Game: $gameName"
        
        // Check if we have valid process ID
        if (processId == -1) {
            Toast.makeText(this, "Invalid process ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        // Initialize EasyModeManager
        easyModeManager = EasyModeManager(processId)
        
        // Initialize the manager
        lifecycleScope.launch {
            val initialized = easyModeManager.initialize()
            if (!initialized) {
                Toast.makeText(this@EasyModeActivity, "Failed to initialize hacks", Toast.LENGTH_SHORT).show()
                binding.tvStatus.text = "Status: Initialization failed"
            } else {
                binding.tvStatus.text = "Status: Ready"
            }
        }
        
        // Set up speed slider
        binding.sliderSpeed.addOnChangeListener { _, value, _ ->
            binding.tvSpeedValue.text = "Speed: ${String.format("%.1f", value)}x"
        }
        
        // Set up button click listeners
        setupButtonListeners()
    }
    
    private fun setupButtonListeners() {
        // Fly hack button
        binding.btnFlyHack.setOnClickListener {
            lifecycleScope.launch {
                binding.tvStatus.text = "Status: Enabling fly hack..."
                val success = easyModeManager.enableFlyHack()
                binding.tvStatus.text = if (success) {
                    "Status: Fly hack enabled"
                } else {
                    "Status: Failed to enable fly hack"
                }
                Toast.makeText(this@EasyModeActivity, 
                    if (success) "Fly hack enabled" else "Failed to enable fly hack", 
                    Toast.LENGTH_SHORT).show()
            }
        }
        
        // Speed hack button
        binding.btnSpeedHack.setOnClickListener {
            lifecycleScope.launch {
                val speedMultiplier = binding.sliderSpeed.value
                binding.tvStatus.text = "Status: Enabling speed hack (${speedMultiplier}x)..."
                val success = easyModeManager.enableSpeedHack(speedMultiplier)
                binding.tvStatus.text = if (success) {
                    "Status: Speed hack enabled (${speedMultiplier}x)"
                } else {
                    "Status: Failed to enable speed hack"
                }
                Toast.makeText(this@EasyModeActivity, 
                    if (success) "Speed hack enabled" else "Failed to enable speed hack", 
                    Toast.LENGTH_SHORT).show()
            }
        }
        
        // God mode button
        binding.btnGodMode.setOnClickListener {
            lifecycleScope.launch {
                binding.tvStatus.text = "Status: Enabling god mode..."
                val success = easyModeManager.enableGodMode()
                binding.tvStatus.text = if (success) {
                    "Status: God mode enabled"
                } else {
                    "Status: Failed to enable god mode"
                }
                Toast.makeText(this@EasyModeActivity, 
                    if (success) "God mode enabled" else "Failed to enable god mode", 
                    Toast.LENGTH_SHORT).show()
            }
        }
        
        // Unlimited ammo button
        binding.btnUnlimitedAmmo.setOnClickListener {
            lifecycleScope.launch {
                binding.tvStatus.text = "Status: Enabling unlimited ammo..."
                val success = easyModeManager.enableUnlimitedAmmo()
                binding.tvStatus.text = if (success) {
                    "Status: Unlimited ammo enabled"
                } else {
                    "Status: Failed to enable unlimited ammo"
                }
                Toast.makeText(this@EasyModeActivity, 
                    if (success) "Unlimited ammo enabled" else "Failed to enable unlimited ammo", 
                    Toast.LENGTH_SHORT).show()
            }
        }
        
        // Unlimited resources button
        binding.btnUnlimitedResources.setOnClickListener {
            lifecycleScope.launch {
                binding.tvStatus.text = "Status: Enabling unlimited resources..."
                val success = easyModeManager.enableUnlimitedResources()
                binding.tvStatus.text = if (success) {
                    "Status: Unlimited resources enabled"
                } else {
                    "Status: Failed to enable unlimited resources"
                }
                Toast.makeText(this@EasyModeActivity, 
                    if (success) "Unlimited resources enabled" else "Failed to enable unlimited resources", 
                    Toast.LENGTH_SHORT).show()
            }
        }
        
        // Custom hack button
        binding.btnCustomHack.setOnClickListener {
            // Launch value editor activity
            val intent = intent.setClass(this, com.gamemodai.ValueEditorActivity::class.java)
            startActivity(intent)
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}