package com.gamemodai

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.gamemodai.databinding.ActivityGameScanBinding
import com.gamemodai.memory.MemoryScanner
import com.gamemodai.memory.GameValueType
import com.gamemodai.memory.ValueType
import com.gamemodai.memory.SearchType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class GameScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameScanBinding
    private lateinit var memoryScanner: MemoryScanner
    private lateinit var gameValueAdapter: GameValueAdapter
    
    private var packageName: String = ""
    private var processId: Int = -1
    private var gameName: String = ""
    
    private val gameValues = mutableListOf<GameValue>()
    private val valueTypes = listOf(
        ValueType.INT, 
        ValueType.FLOAT, 
        ValueType.LONG, 
        ValueType.DOUBLE,
        ValueType.BYTE,
        ValueType.SHORT,
        ValueType.STRING,
        ValueType.ENCRYPTED
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameScanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Get intent data
        packageName = intent.getStringExtra("PACKAGE_NAME") ?: ""
        processId = intent.getIntExtra("PROCESS_ID", -1)
        gameName = intent.getStringExtra("GAME_NAME") ?: ""
        
        // Set up toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = gameName
        
        // Initialize memory scanner
        memoryScanner = MemoryScanner()
        
        // Set up recycler view
        setupRecyclerView()
        
        // Set up value type spinner
        setupValueTypeSpinner()
        
        // Set up search button
        binding.btnSearch.setOnClickListener {
            val searchValue = binding.etSearchValue.text.toString()
            val selectedValueType = valueTypes[binding.spinnerValueType.selectedItemPosition]
            searchForValue(selectedValueType, searchValue)
        }
        
        // Set up AI scan button
        binding.btnAiScan.setOnClickListener {
            scanWithAI()
        }
        
        // Check for encrypted files
        checkForEncryptedFiles()
        
        // Initialize scanner
        initializeScanner()
    }
    
    private fun setupRecyclerView() {
        gameValueAdapter = GameValueAdapter(gameValues) { gameValue ->
            // Handle value selection - open editor
            val intent = android.content.Intent(this, ValueEditorActivity::class.java).apply {
                putExtra("ADDRESS", gameValue.address)
                putExtra("VALUE_TYPE", gameValue.valueType.name)
                putExtra("CURRENT_VALUE", gameValue.value)
                putExtra("PROCESS_ID", processId)
            }
            startActivity(intent)
        }
        
        binding.rvGameValues.apply {
            layoutManager = LinearLayoutManager(this@GameScanActivity)
            adapter = gameValueAdapter
        }
    }
    
    private fun setupValueTypeSpinner() {
        val valueTypeNames = valueTypes.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, valueTypeNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerValueType.adapter = adapter
    }
    
    private fun initializeScanner() {
        CoroutineScope(Dispatchers.Main).launch {
            binding.progressBar.visibility = View.VISIBLE
            binding.tvStatus.text = "Initializing scanner..."
            
            val success = withContext(Dispatchers.IO) {
                memoryScanner.initialize(processId)
            }
            
            if (success) {
                binding.tvStatus.text = "Scanner initialized. Ready to search."
            } else {
                binding.tvStatus.text = "Failed to initialize scanner. Make sure you have root access."
                Toast.makeText(this@GameScanActivity, "Failed to initialize scanner", Toast.LENGTH_SHORT).show()
            }
            
            binding.progressBar.visibility = View.GONE
        }
    }
    
    private fun searchForValue(valueType: ValueType, searchValue: String) {
        if (searchValue.isEmpty()) {
            Toast.makeText(this, "Please enter a search value", Toast.LENGTH_SHORT).show()
            return
        }
        
        CoroutineScope(Dispatchers.Main).launch {
            binding.progressBar.visibility = View.VISIBLE
            binding.tvStatus.text = "Searching for $searchValue..."
            
            val results = withContext(Dispatchers.IO) {
                memoryScanner.scanForValue(processId, valueType, searchValue)
            }
            
            // Update UI with results
            gameValues.clear()
            results.forEach { memoryAddress ->
                val value = withContext(Dispatchers.IO) {
                    readMemoryValue(memoryAddress.address, memoryAddress.valueType)
                }
                gameValues.add(GameValue(memoryAddress.address, memoryAddress.valueType, value))
            }
            
            gameValueAdapter.notifyDataSetChanged()
            
            binding.tvStatus.text = "Found ${results.size} results"
            binding.progressBar.visibility = View.GONE
        }
    }
    
    private fun scanWithAI() {
        CoroutineScope(Dispatchers.Main).launch {
            binding.progressBar.visibility = View.VISIBLE
            binding.tvStatus.text = getString(R.string.ai_analyzing)
            
            val results = withContext(Dispatchers.IO) {
                memoryScanner.scanForGameValues(processId)
            }
            
            // Update UI with results
            gameValues.clear()
            
            results.forEach { (valueType, addresses) ->
                addresses.forEach { memoryAddress ->
                    val value = withContext(Dispatchers.IO) {
                        readMemoryValue(memoryAddress.address, memoryAddress.valueType)
                    }
                    gameValues.add(GameValue(
                        memoryAddress.address, 
                        memoryAddress.valueType, 
                        value,
                        valueType.name
                    ))
                }
            }
            
            gameValueAdapter.notifyDataSetChanged()
            
            binding.tvStatus.text = "AI found ${gameValues.size} potential game values"
            binding.progressBar.visibility = View.GONE
        }
    }
    
    private suspend fun readMemoryValue(address: Long, valueType: ValueType): String {
        return withContext(Dispatchers.IO) {
            try {
                val memPath = "/proc/$processId/mem"
                val size = valueType.size
                
                val readCmd = "dd if=$memPath bs=1 skip=$address count=$size 2>/dev/null"
                val result = com.topjohnwu.superuser.Shell.cmd(readCmd).exec()
                
                if (result.isSuccess) {
                    val bytes = result.out.joinToString("").toByteArray()
                    
                    when (valueType) {
                        ValueType.INT -> {
                            val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            buffer.getInt().toString()
                        }
                        ValueType.FLOAT -> {
                            val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            buffer.getFloat().toString()
                        }
                        ValueType.LONG -> {
                            val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            buffer.getLong().toString()
                        }
                        ValueType.DOUBLE -> {
                            val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            buffer.getDouble().toString()
                        }
                        ValueType.BYTE -> {
                            bytes[0].toString()
                        }
                        ValueType.SHORT -> {
                            val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            buffer.getShort().toString()
                        }
                        ValueType.STRING -> {
                            String(bytes)
                        }
                        ValueType.ENCRYPTED -> {
                            // Try to decrypt the value
                            decryptValue(bytes)
                        }
                    }
                } else {
                    "Error"
                }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        }
    }
    
    private fun decryptValue(bytes: ByteArray): String {
        // Try common decryption methods
        val potentialKeys = listOf(0xFF, 0xAA, 0x55, 0x33, 0xCC)
        
        for (key in potentialKeys) {
            val decrypted = bytes.map { (it.toInt() xor key).toByte() }.toByteArray()
            
            try {
                // Try to interpret as an integer
                val intValue = java.nio.ByteBuffer.wrap(decrypted).order(java.nio.ByteOrder.LITTLE_ENDIAN).getInt()
                if (intValue in 0..999999) {
                    return intValue.toString()
                }
            } catch (e: Exception) {
                // Ignore and try next key
            }
        }
        
        // If no decryption worked, return the raw bytes as hex
        return bytes.joinToString("") { "%02X".format(it) }
    }
    
    private fun checkForEncryptedFiles() {
        CoroutineScope(Dispatchers.Main).launch {
            binding.progressBar.visibility = View.VISIBLE
            binding.tvStatus.text = "Checking for encrypted game files..."
            
            val encryptedFiles = withContext(Dispatchers.IO) {
                findEncryptedFiles(packageName)
            }
            
            if (encryptedFiles.isNotEmpty()) {
                binding.tvEncryptedFiles.visibility = View.VISIBLE
                binding.tvEncryptedFiles.text = "Found ${encryptedFiles.size} encrypted files"
                
                // Decrypt files
                val decryptedCount = withContext(Dispatchers.IO) {
                    decryptFiles(encryptedFiles)
                }
                
                binding.tvEncryptedFiles.text = "Decrypted $decryptedCount/${encryptedFiles.size} files"
            } else {
                binding.tvEncryptedFiles.visibility = View.GONE
            }
            
            binding.progressBar.visibility = View.GONE
        }
    }
    
    private fun findEncryptedFiles(packageName: String): List<File> {
        val encryptedFiles = mutableListOf<File>()
        
        try {
            // Get the app's data directory
            val dataDir = File("/data/data/$packageName")
            
            // Check if we have access to the directory
            if (!dataDir.exists() || !dataDir.canRead()) {
                return emptyList()
            }
            
            // Look for potential encrypted files
            findEncryptedFilesRecursive(dataDir, encryptedFiles)
            
            // Also check external storage if available
            val externalDir = File("/sdcard/Android/data/$packageName")
            if (externalDir.exists() && externalDir.canRead()) {
                findEncryptedFilesRecursive(externalDir, encryptedFiles)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        return encryptedFiles
    }
    
    private fun findEncryptedFilesRecursive(directory: File, encryptedFiles: MutableList<File>) {
        val files = directory.listFiles() ?: return
        
        for (file in files) {
            if (file.isDirectory) {
                findEncryptedFilesRecursive(file, encryptedFiles)
            } else {
                // Check if file might be encrypted
                if (isLikelyEncrypted(file)) {
                    encryptedFiles.add(file)
                }
            }
        }
    }
    
    private fun isLikelyEncrypted(file: File): Boolean {
        // Check file extension for common encrypted formats
        val encryptedExtensions = listOf(".dat", ".bin", ".enc", ".crypt", ".save")
        if (encryptedExtensions.any { file.name.endsWith(it, ignoreCase = true) }) {
            return true
        }
        
        // Check file size (encrypted files are often multiples of common block sizes)
        val fileSize = file.length()
        if (fileSize > 0 && (fileSize % 8 == 0L || fileSize % 16 == 0L)) {
            // Read a small sample to check for entropy
            try {
                val buffer = ByteArray(Math.min(fileSize.toInt(), 1024))
                file.inputStream().use { it.read(buffer) }
                
                // High entropy is a sign of encryption
                return hasHighEntropy(buffer)
            } catch (e: Exception) {
                // If we can't read the file, it might be protected
                return true
            }
        }
        
        return false
    }
    
    private fun hasHighEntropy(data: ByteArray): Boolean {
        // Calculate Shannon entropy
        val frequencies = IntArray(256)
        for (b in data) {
            frequencies[b.toInt() and 0xFF]++
        }
        
        var entropy = 0.0
        for (freq in frequencies) {
            if (freq > 0) {
                val p = freq.toDouble() / data.size
                entropy -= p * Math.log(p) / Math.log(2.0)
            }
        }
        
        // Entropy above 7.0 is typically encrypted or compressed data
        return entropy > 7.0
    }
    
    private fun decryptFiles(encryptedFiles: List<File>): Int {
        var decryptedCount = 0
        
        for (file in encryptedFiles) {
            try {
                // Try common decryption methods
                if (tryDecryptFile(file)) {
                    decryptedCount++
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        
        return decryptedCount
    }
    
    private fun tryDecryptFile(file: File): Boolean {
        try {
            // Read the encrypted file
            val encryptedData = file.readBytes()
            
            // Try common decryption methods
            val decryptedData = tryCommonDecryptions(encryptedData)
            
            // If decryption was successful, write to a new file
            if (decryptedData != null) {
                val decryptedFile = File(file.parentFile, "${file.nameWithoutExtension}_decrypted${file.extension}")
                decryptedFile.writeBytes(decryptedData)
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        return false
    }
    
    private fun tryCommonDecryptions(data: ByteArray): ByteArray? {
        // Try XOR with common keys
        val commonKeys = listOf(0xFF, 0xAA, 0x55, 0x33, 0xCC)
        
        for (key in commonKeys) {
            val decrypted = data.map { (it.toInt() xor key).toByte() }.toByteArray()
            
            // Check if decryption looks valid
            if (isLikelyValidDecryption(decrypted)) {
                return decrypted
            }
        }
        
        // Try byte reversal (endianness swap)
        val reversed = data.toList().chunked(4).flatMap { it.reversed() }.toByteArray()
        if (isLikelyValidDecryption(reversed)) {
            return reversed
        }
        
        // Try simple offset/Caesar cipher
        for (offset in 1..255) {
            val offsetDecrypted = data.map { ((it.toInt() + offset) % 256).toByte() }.toByteArray()
            if (isLikelyValidDecryption(offsetDecrypted)) {
                return offsetDecrypted
            }
        }
        
        return null
    }
    
    private fun isLikelyValidDecryption(data: ByteArray): Boolean {
        // Check for common file signatures/magic numbers
        val signatures = mapOf(
            "PNG" to byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47),
            "JPEG" to byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()),
            "XML" to byteArrayOf(0x3C, 0x3F, 0x78, 0x6D), // <?xml
            "JSON" to byteArrayOf(0x7B), // {
            "ZIP" to byteArrayOf(0x50, 0x4B, 0x03, 0x04)
        )
        
        for ((_, signature) in signatures) {
            if (data.size >= signature.size) {
                var matches = true
                for (i in signature.indices) {
                    if (data[i] != signature[i]) {
                        matches = false
                        break
                    }
                }
                if (matches) return true
            }
        }
        
        // Check for text content
        val textChars = data.count { it in 32..126 }
        if (data.size > 0 && textChars.toDouble() / data.size > 0.7) {
            return true
        }
        
        return false
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}

data class GameValue(
    val address: Long,
    val valueType: ValueType,
    val value: String,
    val gameValueType: String = ""
)